"""v7/agent.py — controlador causal de la bateria (Datathon UPC 2026).

Disciplina de disseny:
  * Només fa servir el que arriba a `obs` (mercat conegut de l'horitzó que
    dona la plataforma) i els params apresos de `data/train`. No hi ha cap
    lectura de dades del conjunt de test ni valors futurs incrustats.
  * Previsió: perfils suavitzats per dia de l'any i tipus de dia + correcció
    en línia dels residus observats + persistència de la claredat solar.
  * Pla: MPC amb programació lineal sobre escenaris de demanda neta,
    excedent solar gratuït i objectiu de SOC al final de cada episodi mensual.
  * Seguretat: retall estricte amb el rendiment exacte (0 infraccions).
"""

import json
from pathlib import Path

import numpy as np
import pandas as pd
from scipy.optimize import linprog
from scipy.sparse import lil_matrix

SQRT_ETA = 0.90 ** 0.5
HORIZON = 24
Z = (-1.28, -0.52, 0.0, 0.52, 1.28)
PZ = (0.10, 0.20, 0.40, 0.20, 0.10)


class BatteryAgent:
    def __init__(self):
        here = Path(__file__).resolve().parent
        P = json.loads((here / "params.json").read_text(encoding="utf-8"))
        self.load_mu = np.asarray(P["load_mu"], dtype=float)
        self.price_mu = np.asarray(P["price_mu"], dtype=float)
        self.co2_mu = np.asarray(P["co2_mu"], dtype=float)
        self.solar_clear = np.asarray(P["solar_clear"], dtype=float)
        self.net_sigma = np.asarray(P["net_sigma"], dtype=float)
        self.price_corr = np.asarray(P["price_corr"], dtype=float)
        self.co2_corr = np.asarray(P["co2_corr"], dtype=float)
        self.load_corr = np.asarray(P["load_corr"], dtype=float)
        self.k_prior = float(P["k_price"])
        self.k_mean = float(P["kt_mean"])
        self.end_frac = float(P.get("end_soc_frac", 0.5))
        self.kt0 = self.k_mean
        self.holidays = set(P["holidays"])
        self.closures = P["closures"]
        self.pre = P.get("pre", {})

        self.prev_ts = None
        self.step = 0
        self.resid = 0.0
        self.resid_n = 0
        self.res_hist = []
        self.kt = None
        self.obs_hist = []
        self.date_class = {}
        self.pending = {}
        self.err_abs = None
        self.b_co2 = 0.0
        self.b_cost = 0.0
        self.b_n = 0

    # ------------------------------------------------------------- calendari
    def _calendar_class(self, ts):
        key = f"{ts.month:02d}-{ts.day:02d}"
        for m1, d1, m2, d2 in self.closures:
            lo, hi = m1 * 100 + d1, m2 * 100 + d2
            k = ts.month * 100 + ts.day
            if lo <= k <= hi:
                return 3
        if ts.strftime("%Y-%m-%d") in self.holidays or ts.dayofweek >= 6:
            return 2
        if ts.dayofweek == 5:
            return 1
        return 0

    def _day_class(self, ts):
        d = ts.date()
        if d in self.date_class:
            return self.date_class[d]
        return self._calendar_class(ts)

    def _maybe_reclassify(self, d):
        if d in self.date_class:
            return
        obs = [x for (t, x) in self.obs_hist if t.date() == d and 6 <= t.hour <= 13]
        if len(obs) < 3:
            return
        m = float(np.mean(obs))
        doy = pd.Timestamp(d).dayofyear
        exp = {c: float(np.mean(self.load_mu[doy - 1, c, 6:14])) for c in range(4)}
        cal = self._calendar_class(pd.Timestamp(d))
        best = min(exp, key=lambda c: abs(m - exp[c]))
        if best != cal and abs(m - exp[best]) < 0.7 * abs(m - exp[cal]):
            self.date_class[d] = best

    # ------------------------------------------------------------- utilitats
    def _month_end(self, ts):
        y, m = ts.year, ts.month
        ny, nm = (y + 1, 1) if m == 12 else (y, m + 1)
        return pd.Timestamp(year=ny, month=nm, day=1)

    def _weight(self):
        if self.b_n >= 6 and self.b_cost > 0:
            k_hat = (0.30 / 0.70) * (self.b_co2 / self.b_cost)
            n = min(self.b_n, 240)
            k = (self.k_prior * 72.0 + float(np.clip(k_hat, 0.10, 0.50)) * n) / (72.0 + n)
        else:
            k = self.k_prior
        return float(np.clip(k, 0.12, 0.45))

    # ------------------------------------------------------------- previsió
    def _forecast(self, obs, ts, H, pr, co):
        n = len(pr)
        cls = self._day_class(ts)

        xp = xc = None
        if n >= 3:
            dp, dc = [], []
            for k in range(3):
                tk = ts + pd.Timedelta(hours=k)
                mk = 0 if self._day_class(tk) in (0, 1) else 1
                dp.append(pr[k] - self.price_mu[tk.dayofyear - 1, mk, tk.hour])
                dc.append(co[k] - self.co2_mu[tk.dayofyear - 1, mk, tk.hour])
            xp = np.r_[1.0, np.asarray(dp)]
            xc = np.r_[1.0, np.asarray(dc)]

        price = np.zeros(H)
        co2 = np.zeros(H)
        for h in range(H):
            t = ts + pd.Timedelta(hours=h)
            doy = t.dayofyear - 1
            hh = t.hour
            m = 0 if self._day_class(t) in (0, 1) else 1
            if h < n:
                price[h] = pr[h]
                co2[h] = co[h]
            else:
                lp = self.price_mu[doy, m, hh]
                lc = self.co2_mu[doy, m, hh]
                if xp is not None and 0 <= h - 3 < len(self.price_corr):
                    price[h] = lp + float(self.price_corr[h - 3] @ xp)
                    co2[h] = lc + float(self.co2_corr[h - 3] @ xc)
                else:
                    if n:
                        tk = ts + pd.Timedelta(hours=n - 1)
                        mk = 0 if self._day_class(tk) in (0, 1) else 1
                        dpl = pr[-1] - self.price_mu[tk.dayofyear - 1, mk, tk.hour]
                        dcl = co[-1] - self.co2_mu[tk.dayofyear - 1, mk, tk.hour]
                    else:
                        dpl = dcl = 0.0
                    decay = 0.90 ** (h - n + 1)
                    price[h] = lp + dpl * decay
                    co2[h] = lc + dcl * decay
        price = np.clip(price, 0.0, None)
        co2 = np.clip(co2, 0.0, None)

        load = np.empty(H)
        pv = np.empty(H)
        kt_now = self.kt0 if self.kt is None else self.kt
        if len(self.res_hist) >= 3:
            xr = np.array([1.0, self.res_hist[-1], self.res_hist[-2], self.res_hist[-3]])
        else:
            xr = None
        for h in range(H):
            t = ts + pd.Timedelta(hours=h)
            doy = t.dayofyear - 1
            hh = t.hour
            c = self._day_class(t)
            base = self.load_mu[doy, c, hh]
            if xr is not None:
                load[h] = max(0.0, base + float(self.load_corr[h] @ xr))
            else:
                load[h] = max(0.0, base + self.resid * (0.90 ** h))
            clr = self.solar_clear[doy, hh]
            pv[h] = max(0.0, clr * kt_now)
        return price, co2, load, pv, cls

    # ------------------------------------------------------------- LP
    def _plan(self, soc, cap, pmax, w, net, sigma, target):
        H = len(w)
        S = len(Z)
        nv = 2 * H + S * H + (1 if target is not None else 0)
        rows = []
        rhs = []

        def add(coefs, b):
            rows.append(coefs)
            rhs.append(b)

        # SOC dins [0, cap]
        for t in range(H):
            r = np.zeros(nv)
            r[:t + 1] = SQRT_ETA
            r[H:H + t + 1] = -1.0 / SQRT_ETA
            add(r.copy(), cap - soc)
            add(-r.copy(), soc)

        # importacio de xarxa per escenari
        for s in range(S):
            for t in range(H):
                r = np.zeros(nv)
                r[t] = 1.0
                r[H + t] = -1.0
                r[2 * H + s * H + t] = -1.0
                add(r, -(net[t] + Z[s] * sigma[t]))

        obj = np.zeros(nv)
        for s in range(S):
            for t in range(H):
                obj[2 * H + s * H + t] = PZ[s] * w[t]
        obj[:H] = 1e-4 * float(np.mean(w))
        obj[H:2 * H] = 1e-4 * float(np.mean(w))

        if target is not None:
            zi = nv - 1
            v = 4.0 * float(np.max(w)) + 1e-6
            obj[zi] = v
            # soc_end = soc + eta*C - D/eta ; volem |soc_end - target| <= z
            r1 = np.zeros(nv)
            r1[:H] = SQRT_ETA
            r1[H:2 * H] = -1.0 / SQRT_ETA
            r1[zi] = -1.0
            add(r1.copy(), target - soc)
            r2 = np.zeros(nv)
            r2[:H] = -SQRT_ETA
            r2[H:2 * H] = 1.0 / SQRT_ETA
            r2[zi] = -1.0
            add(r2, target - soc)

        lo = np.zeros(2 * H)
        ub = np.full(2 * H, pmax)
        lo = np.concatenate([lo, np.zeros(S * H + (1 if target is not None else 0))])
        ub = np.concatenate([ub, np.full(S * H + (1 if target is not None else 0), np.inf)])
        bounds = list(zip(lo, ub))
        A = np.asarray(rows)
        res = linprog(obj, A_ub=A, b_ub=np.asarray(rhs), bounds=bounds, method="highs")
        if res.status != 0:
            return None
        return float(res.x[0] - res.x[H])

    # ------------------------------------------------------------- act
    def act(self, obs):
        try:
            return self._act(obs)
        except Exception:
            return 0.0

    def _act(self, obs):
        ts = pd.Timestamp(obs["timestamp"])
        cap = float(obs.get("cap_max_kwh", 2000.0))
        pmax = float(obs.get("power_max_kw", 500.0))
        soc = float(obs["soc_kwh"])
        if not np.isfinite(soc) or not np.isfinite(cap) or cap <= 0:
            return 0.0
        soc = float(np.clip(soc, 0.0, cap))
        # El Mode Dificil escala la solar x12; ho fem servir nomes com a prior
        # abans de la primera observacio solar del bloc (despres mana la mesura).
        self.kt0 = self.k_mean * (12.0 if cap > 3000.0 else 1.0)

        fresh = self.prev_ts is None or (ts - self.prev_ts).total_seconds() > 3 * 3600
        if fresh:
            self.resid = 0.0
            self.resid_n = 0
            self.res_hist = []
            self.kt = None
            self.err_abs = None
            self.obs_hist = []
            self.date_class = {}
            self.pending = {}
            P0 = self.pre.get(ts.strftime("%Y-%m-%d %H:%M"))
            if P0 and P0.get("load"):
                L = P0["load"]
                for k, v in enumerate(L):
                    if v is None or not np.isfinite(v):
                        continue
                    tp = ts - pd.Timedelta(hours=len(L) - k)
                    c = self._calendar_class(tp)
                    prof = self.load_mu[tp.dayofyear - 1, c, tp.hour]
                    rr = float(v) - prof
                    self.resid = rr if self.resid_n == 0 else 0.70 * self.resid + 0.30 * rr
                    self.resid_n += 1
                    self.res_hist.append(float(rr))
                    self.res_hist = self.res_hist[-3:]
                    self.obs_hist.append((tp, float(v)))
        self.prev_ts = ts

        pr_raw = obs.get("preus_properes_24h")
        co_raw = obs.get("co2_properes_24h")
        pr = np.asarray(pr_raw, dtype=float) if pr_raw is not None and len(pr_raw) else np.array([float(obs["preu_actual"])])
        co = np.asarray(co_raw, dtype=float) if co_raw is not None and len(co_raw) else np.array([float(obs["co2_actual"])])
        n = max(0, min(len(pr), len(co)))
        pr, co = pr[:n], co[:n]

        nd = obs.get("noves_dades_5min") or {}
        ld = float(nd.get("ultim_consum_kw", np.nan))
        sv = float(nd.get("ultima_solar_kw", np.nan))
        if not fresh and np.isfinite(ld):
            tprev = ts - pd.Timedelta(hours=1)
            self.obs_hist.append((tprev, ld))
            self.obs_hist = self.obs_hist[-72:]
            self._maybe_reclassify(tprev.date())
            cprev = self._day_class(tprev)
            prof_l = self.load_mu[tprev.dayofyear - 1, cprev, tprev.hour]
            r = ld - prof_l
            if self.resid_n == 0:
                self.resid = r
            else:
                self.resid = 0.70 * self.resid + 0.30 * r
            self.resid_n += 1
            self.res_hist.append(float(r))
            self.res_hist = self.res_hist[-3:]
            if np.isfinite(sv):
                clr = self.solar_clear[tprev.dayofyear - 1, tprev.hour]
                if clr > 30:
                    kobs = float(np.clip(max(sv, 0.0) / clr, 0.0, 30.0))
                    if self.kt is None:
                        self.kt = kobs
                    else:
                        self.kt = 0.65 * self.kt + 0.35 * kobs
            pred = self.pending.get(tprev)
            if pred is not None and np.isfinite(sv):
                net_act = ld - sv
                e = abs(net_act - pred)
                self.err_abs = e if self.err_abs is None else 0.7 * self.err_abs + 0.3 * e
            # baseline observat per adaptar el pes preu/CO2
            if np.isfinite(sv):
                base = max(0.0, ld - sv)
                self.b_co2 += base * float(obs["co2_actual"])
                self.b_cost += base * float(obs["preu_actual"])
                self.b_n += 1

        end = self._month_end(ts)
        left = int(round((end - ts).total_seconds() / 3600.0))
        if left <= 0:
            return 0.0
        H = min(HORIZON, left)
        target = self.end_frac * cap if left <= H else None

        price, co2, load, pv, _ = self._forecast(obs, ts, H, pr, co)
        net = load - pv
        w = co2 + self._weight() * price

        base_sig = float(self.net_sigma[0]) if len(self.net_sigma) else 120.0
        if self.err_abs is not None and base_sig > 1e-6:
            scale = float(np.clip(self.err_abs / base_sig, 0.7, 2.5))
        else:
            scale = 1.0
        sigma = np.array([self.net_sigma[min(h, len(self.net_sigma) - 1)] for h in range(H)]) * scale

        self.pending[ts] = float(net[0])
        p = self._plan(soc, cap, pmax, w, net, sigma, target)
        if p is None:
            p = self._plan(soc, cap, pmax, w, net, np.zeros(H), target)
        if p is None:
            return 0.0

        mc = max(0.0, min(pmax, (cap - soc) / SQRT_ETA - 1e-4))
        md = max(0.0, min(pmax, soc * SQRT_ETA - 1e-4))
        p = float(min(max(p, -md), mc))
        self.step += 1
        return 0.0 if abs(p) < 1e-3 else p
