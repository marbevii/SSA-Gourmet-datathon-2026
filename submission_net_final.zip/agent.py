"""
agent.py — BatteryAgent per al MODE DIFÍCIL (6.000 kWh, ±1.500 kW, solar x12, mercat visible 3 h).

MPC amb programació lineal sobre un horitzó de 30 h:
  * preu i CO2: 3 h exactes (obs) + predicció (perfil mes/dia/hora + regressió sobre les desviacions recents)
  * consum: perfil mes/dia/hora + regressió sobre les desviacions recents
  * solar: corba de sol clar per dia de l'any x índex de claredat recent (persistència que decau)
  * la demanda neta limita la descàrrega útil (no aboquem a la xarxa) i l'excedent solar carrega gratis
Funciona també en Mode Estàndard (llegeix cap_max_kwh / power_max_kw d'obs).
"""
import json
from pathlib import Path

import numpy as np
from scipy.optimize import linprog

ETA = 0.90 ** 0.5
DST = [("2025-03-30 02:00", "2025-10-26 03:00"), ("2026-03-29 02:00", "2026-10-25 03:00"), ("2027-03-28 02:00", "2027-10-31 03:00")]
CFG = {"end_ts": "2026-09-01 00:00:00", "H": 24, "kappa": 0.0, "scen": 1, "scen_scale": 1.4, "S": 3, "pscale": 1.0, "Hs": 14, "q_out": 0.867, "eps": 1e-7, "term": 0.0}


class Series:
    """Historial d'una variable amb desviacions respecte al perfil; índex = hores consecutives del bloc actual."""
    def __init__(self, mdl):
        self.prof = np.asarray(mdl["prof"]); self.warm = np.asarray(mdl["warm"])
        self.cold = np.asarray(mdl["cold"]); self.cold1 = np.asarray(mdl["cold1"]); self.sig = np.asarray(mdl["sig"])
        self.dev = []                      # desviacions conegudes, consecutives, fins a l'origen L

    def reset(self):
        self.dev = []

    def predict(self, prof_future, hL):
        """prof_future[k-1] = perfil a L+k; hL = hora del dia de l'origen L. Retorna predicció a L+1..L+n."""
        n = len(prof_future); d = self.dev; m = len(d)
        if m == 0:
            return np.array(prof_future, dtype=float)
        if m >= 24:
            a = np.asarray(d[-24:]); k = np.arange(1, n + 1)
            lagk = np.where(k <= 24, a[np.clip(k - 1, 0, 23)], a[np.clip(k - 25, 0, 23)])
            X = np.c_[np.ones(n), np.full(n, a[-1]), np.full(n, a[-2]), np.full(n, a[-3]), lagk, np.full(n, a.mean())]
            dv = (X * self.warm[hL, :n]).sum(1)
        elif m >= 3:
            X = np.array([1.0, d[-1], d[-2], d[-3]]); dv = self.cold[hL, :n] @ X
        else:
            dv = self.cold1[hL, :n] @ np.array([1.0, d[-1]])
        return np.asarray(prof_future) + dv


class BatteryAgent:
    def __init__(self):
        here = Path(__file__).resolve().parent
        with open(here / "model.json", encoding="utf-8") as f:
            M = json.load(f)
        self.cfg = dict(CFG)
        cp = here / "config.json"
        if cp.exists():
            with open(cp, encoding="utf-8") as f:
                self.cfg.update(json.load(f))
        self.R = float(self.cfg.get("R", M["R"])); self.rho = float(M.get("rho_pc", 0.3))
        self._smat = {}
        import pandas as pd
        self.blocks = [(pd.Timestamp(s), pd.Timestamp(e)) for s, e in M.get("blocks", [])]
        self.pre = M.get("pre", {})
        self.jump = None
        self.daytype = M.get("daytype", {}); self.hol_price = set(M.get("hol_price", []))
        self.override = {}                 # data -> dia efectiu detectat en línia
        self.load_raw = []                 # (timestamp, consum) de les darreres hores
        self._dl = None; self._dp = None
        self.price = Series(M["price"]); self.co2 = Series(M["co2"]); self.load = Series(M["load"])
        pv = M["pv"]
        self.clear = np.asarray(pv["clear"]); self.kt_mean = float(pv["kt_mean"])
        self.pv_day = np.asarray(pv["day"]); self.pv_night = np.asarray(pv["night"])
        self.pv_err = np.asarray(M["pv_err"]); self.pv_edges = M["pv_err_edges"]; self.load_err = np.asarray(M["load_err"])
        self.kt1 = None
        self.pv_hist = []                 # (pv, clear) de les darreres hores
        self.kt_last = None; self.kt_fresh = False
        self.prev_ts = None; self.step = 0; self.outage = False
        self.last_load = None
        self._mat = {}
        self.historial = []

    # ------------------------------------------------------------- temps
    def _parts(self, ts, k):
        """(mes0, dow, hora, hora solar) per a ts + k hores de simulació (salta al bloc de test següent si cal)."""
        import pandas as pd
        ts = pd.Timestamp(ts); k = np.atleast_1d(k)
        t = pd.DatetimeIndex(ts + pd.to_timedelta(k, unit="h")); self.jump = None
        for i, (s, e) in enumerate(self.blocks):
            if s <= ts < e:
                left = int(round((e - ts).total_seconds() / 3600.0))
                if i + 1 < len(self.blocks) and (k >= left).any():
                    t = pd.DatetimeIndex(np.where(k >= left, self.blocks[i + 1][0] + pd.to_timedelta(k - left, unit="h"), t))
                    self.jump = (left, str(self.blocks[i + 1][0]))
                break
        self._dl, self._dp = self._eff(t)
        off = np.ones(len(t), dtype=int)
        for a_, b_ in DST:
            off[(t >= pd.Timestamp(a_)) & (t < pd.Timestamp(b_))] = 2
        u = t - pd.to_timedelta(off, unit="h")                     # hora solar (UTC) per a la corba de cel clar
        return t.month.values - 1, t.dayofweek.values, t.hour.values, (u.dayofyear.values - 1, u.hour.values)

    def _eff(self, t):
        """Dia efectiu per al consum (festius i tancaments) i per al preu (festius nacionals)."""
        import pandas as pd
        dow = t.dayofweek.values.copy(); dl = dow.copy(); dp = dow.copy()
        if not (self.daytype or self.override or self.hol_price):
            return dl, dp
        ds = t.strftime("%Y-%m-%d").values
        for d in set(ds):
            m = ds == d; w = int(dow[m][0])
            if d in self.hol_price: dp[m] = 6
            if w >= 5: continue
            if d in self.override: dl[m] = self.override[d]
            elif d in self.daytype: dl[m] = self._template(d)
        return dl, dp

    def _template(self, d):
        import pandas as pd
        if self.daytype.get(d) == "C":
            return 7
        p = pd.Timestamp(d) - pd.Timedelta(days=1); ps = p.strftime("%Y-%m-%d")
        return 5 if (p.dayofweek < 5 and ps not in self.daytype) else 6

    def _detect(self, ts):
        """Amb el consum del matí, decideix si avui és feiner, festiu o tancament (corregeix el calendari)."""
        import pandas as pd
        ts = pd.Timestamp(ts); d = ts.strftime("%Y-%m-%d")
        if ts.dayofweek >= 5:
            return
        today = [(t, v) for t, v in self.load_raw if v is not None and t.strftime("%Y-%m-%d") == d]
        morn = [(t.hour, v) for t, v in today if 7 <= t.hour <= 12]; night = [(t.hour, v) for t, v in today if 1 <= t.hour <= 5]
        if not morn:
            return
        m = ts.month - 1; cal = int(ts.dayofweek)
        cur = self.override.get(d, self._template(d) if d in self.daytype else cal)
        p = ts - pd.Timedelta(days=1); hol = 5 if (p.dayofweek < 5 and p.strftime("%Y-%m-%d") not in self.daytype) else 6
        err = {}
        for T in (cal, hol, 7):
            P = self.load.prof[m, T]
            adj = np.mean([v - P[h] for h, v in night]) if night else 0.0
            err[T] = float(np.mean([abs(v - P[h] - adj) for h, v in morn]))
        best = min(err, key=err.get)
        if best != cur and err[best] < 0.7 * err[cur]:
            self.override[d] = best

    def _load_devs(self):
        import pandas as pd
        if not self.load_raw:
            self.load.dev = []; return
        t = pd.DatetimeIndex([x[0] for x in self.load_raw]); dl, _ = self._eff(t)
        P = self.load.prof[t.month.values - 1, dl, t.hour.values]; out = []; last = 0.0
        for (tt, v), p in zip(self.load_raw, P):
            last = (v - p) if v is not None else last; out.append(last)
        self.load.dev = out

    # ------------------------------------------------------------- memòria
    def _update(self, obs):
        ts = obs["timestamp"]
        try:
            gap = (ts - self.prev_ts).total_seconds() / 3600.0 if self.prev_ts is not None else 1.0
        except Exception:
            gap = 1.0
        fresh_block = False
        if abs(gap - 1.0) > 1e-6 or self.step == 0:      # inici de bloc: buidem i, si podem, carreguem el dia anterior
            for s in (self.price, self.co2, self.load): s.reset()
            self.pv_hist = []; self.kt_last = None; self.kt_fresh = False; self.kt1 = None; self.load_raw = []
            fresh_block = True
            P = self.pre.get(str(ts))
            if P:
                import pandas as pd
                mi, di, hi, uu = self._parts(ts, np.arange(-24, 0)); DD = {"price": self._dp, "co2": di}
                for s, key in ((self.price, "price"), (self.co2, "co2")):
                    v = np.array([np.nan if x is None else x for x in P[key]], dtype=float)
                    if np.isfinite(v).all():
                        s.dev = list(v - s.prof[mi, DD[key], hi])
                v = np.array([np.nan if x is None else x for x in P["load"]], dtype=float)
                if np.isfinite(v).all() and (v > 50).all():
                    self.load_raw = [(pd.Timestamp(ts) + pd.Timedelta(hours=int(k)), float(x)) for k, x in zip(range(-24, 0), v)]
                pv = np.array([np.nan if x is None else x for x in P["pv"]], dtype=float); c = self.clear[uu[0], uu[1]]
                lit = np.where((c > 60) & np.isfinite(pv))[0]
                if len(lit) >= 3:
                    j = lit[-3:]; self.kt_last = float(np.clip(pv[j].sum() / c[j].sum(), 0.0, 1.5)); self.kt1 = float(np.clip(pv[j[-1]] / c[j[-1]], 0.0, 1.5))
        self.prev_ts = ts
        # preu / CO2: coneguts t..t+2  -> l'origen és L = t+2
        pr = np.asarray(obs.get("preus_properes_24h") or [obs["preu_actual"]], dtype=float)
        co = np.asarray(obs.get("co2_properes_24h") or [obs["co2_actual"]], dtype=float)
        n = min(len(pr), len(co)); pr, co = pr[:n], co[:n]
        mi, di, hi, _ = self._parts(ts, np.arange(n))
        dp = pr - self.price.prof[mi, self._dp, hi]; dc = co - self.co2.prof[mi, di, hi]
        if fresh_block:
            self.price.dev = self.price.dev + list(dp); self.co2.dev = self.co2.dev + list(dc)
        else:
            self.price.dev.append(dp[-1]); self.co2.dev.append(dc[-1])
        # telemetria: hora t-1 -> origen L = t-1
        nd = obs.get("noves_dades_5min") or {}
        ld = float(nd.get("ultim_consum_kw", np.nan)); sv = float(nd.get("ultima_solar_kw", np.nan))
        mi, di, hi, dy = self._parts(ts, -1)
        self.outage = bool(np.isfinite(ld) and np.isfinite(sv) and abs(ld) < 1 and abs(sv) < 1 and not fresh_block)
        if fresh_block:
            pass                                   # la telemetria d'aquest pas no és de l'hora anterior real
        else:
            import pandas as pd
            self.load_raw.append((pd.Timestamp(ts) - pd.Timedelta(hours=1), ld if (np.isfinite(ld) and ld > 50) else None))
            self.load_raw = self.load_raw[-60:]
            try:
                self._detect(pd.Timestamp(ts) - pd.Timedelta(hours=1))
            except Exception:
                pass
        self._load_devs()
        c = self.clear[dy[0][0], dy[1][0]]
        if np.isfinite(sv) and not self.outage and not fresh_block:
            self.pv_hist.append((max(sv, 0.0), c)); self.pv_hist = self.pv_hist[-3:]
            lit = [(p, q) for p, q in self.pv_hist if q > 60]
            if c > 60 and lit:
                self.kt_last = float(np.clip(sum(p for p, _ in lit) / sum(q for _, q in lit), 0.0, 1.5)); self.kt_fresh = True
                self.kt1 = float(np.clip(max(sv, 0.0) / c, 0.0, 1.5))
            else:
                self.kt_fresh = False
        for s in (self.price, self.co2): s.dev = s.dev[-60:]
        return pr, co

    # ------------------------------------------------------------- prediccions
    def _forecasts(self, obs, H, pr, co):
        ts = obs["timestamp"]; n = len(pr)
        mi, di, hi, dy = self._parts(ts, np.arange(H))
        price = np.empty(H); co2 = np.empty(H)
        price[:n], co2[:n] = pr, co
        if H > n:
            hL = int(hi[n - 1])
            price[n:] = self.price.predict(self.price.prof[mi[n:], self._dp[n:], hi[n:]], hL)
            co2[n:] = self.co2.predict(self.co2.prof[mi[n:], di[n:], hi[n:]], hL)
        dl_, dp_ = self._dl, self._dp
        load = self.load.predict(self.load.prof[mi, dl_, hi], int((hi[0] - 1) % 24))
        clr = self.clear[dy[0], dy[1]]
        if self.kt_last is None:
            pv = clr * self.kt_mean
        else:
            B = self.pv_day if self.kt_fresh else self.pv_night
            pv = clr * (B[:H, 0] + B[:H, 1] * (self.kt_last - self.kt_mean) + B[:H, 2] * (self.kt1 - self.kt_mean))
        pv = np.clip(pv, 0.0, clr * 1.25)
        if self.jump is not None and self.jump[0] < H:
            j = max(self.jump[0], n); P = self.pre.get(self.jump[1])
            lev = {"price": 0.0, "co2": 0.0, "load": 0.0}
            if P:
                import pandas as pd
                q = pd.DatetimeIndex(pd.Timestamp(self.jump[1]) + pd.to_timedelta(np.arange(-24, 0), unit="h"))
                ql, qp = self._eff(q); QD = {"price": qp, "co2": q.dayofweek.values, "load": ql}
                for s, key in ((self.price, "price"), (self.co2, "co2"), (self.load, "load")):
                    v = np.array([np.nan if x is None else x for x in P[key]], dtype=float)
                    if np.isfinite(v).all():
                        lev[key] = float(np.mean(v - s.prof[q.month.values - 1, QD[key], q.hour.values]))
            price[j:] = self.price.prof[mi[j:], dp_[j:], hi[j:]] + lev["price"]
            co2[j:] = self.co2.prof[mi[j:], di[j:], hi[j:]] + lev["co2"]
            j0 = self.jump[0]
            load[j0:] = self.load.prof[mi[j0:], dl_[j0:], hi[j0:]] + lev["load"]
            pv[j0:] = clr[j0:] * self.kt_mean
        return np.maximum(price, 0.0), np.maximum(co2, 0.0), np.maximum(load, 0.0), pv

    def _scenarios(self, clr0):
        """Errors possibles de la demanda neta de l'hora actual (equiprobables)."""
        if not self.cfg["scen"]:
            return np.zeros(1)
        el = self.load_err if len(self.load.dev) >= 3 else self.load_err * 2.0
        if clr0 > 60:
            kt = self.kt_mean if self.kt_last is None else self.kt_last
            b = 0 if kt < self.pv_edges[0] else (1 if kt < self.pv_edges[1] else 2)
            ep = self.pv_err[0 if self.kt_fresh else 1][b] * clr0
        else:
            ep = np.zeros(1)
        return (el[:, None] - ep[None, :]).ravel() * self.cfg["scen_scale"]

    # ------------------------------------------------------------- LP
    def _matrix(self, H):
        if H not in self._mat:
            L = np.tril(np.ones((H, H))); I = np.eye(H); Z = np.zeros((H, H))
            S = np.hstack([ETA * L, -L / ETA, Z])
            self._mat[H] = np.vstack([S, -S, np.hstack([I, -I, -I])])
        return self._mat[H]

    def _plan(self, soc, cap, pmax, w, net, v_term, errs):
        H = len(w); eps = self.cfg["eps"]; S = len(errs)
        cost = np.r_[np.full(H, eps - v_term * ETA), np.full(H, eps + v_term / ETA), w]
        if self.outage:
            cost[H:2 * H] += w * self.cfg["q_out"] ** (np.arange(H) + 1)
        b = np.r_[np.full(H, cap - soc), np.full(H, soc), -net]
        A = self._matrix(H)
        if S > 1:
            # hora 0 amb S escenaris: g0_s >= net0 + err_s + c0 - d0, cost esperat w0 * mitjana(g0_s)
            cost[2 * H] = 0.0
            E = np.zeros((S, 3 * H + S)); E[:, 0] = 1.0; E[:, H] = -1.0; E[np.arange(S), 3 * H + np.arange(S)] = -1.0
            A = np.vstack([np.hstack([A, np.zeros((A.shape[0], S))]), E])
            A[2 * H, :] = 0.0                      # desactivem la restricció determinista de l'hora 0
            b = np.r_[b, -(net[0] + errs)]; b[2 * H] = 0.0
            cost = np.r_[cost, np.full(S, w[0] / S)]
        res = linprog(cost, A_ub=A, b_ub=b,
                      bounds=[(0, pmax)] * (2 * H) + [(0, None)] * (H + (S if S > 1 else 0)), method="highs")
        if res.status != 0:
            return None
        return float(res.x[0] - res.x[H])

    # ------------------------------------------------------------- LP estocàstic (2 etapes)
    ZS = {1: [0.0], 3: [-0.97, 0.0, 0.97], 5: [-1.28, -0.52, 0.0, 0.52, 1.28], 7: [-1.47, -0.79, -0.37, 0.0, 0.37, 0.79, 1.47]}

    def _smatrix(self, H, S, Sn):
        key = (H, S, Sn)
        if key not in self._smat:
            M = H - 3; nv = 9 + S * 3 * M + Sn; rows = []
            def soc_row(k, s):
                r = np.zeros(nv); a = min(k, 2) + 1
                r[0:a] = ETA; r[3:3 + a] = -1.0 / ETA
                if k >= 3:
                    o = 9 + s * 3 * M; j = k - 3 + 1
                    r[o:o + j] = ETA; r[o + M:o + M + j] = -1.0 / ETA
                return r
            for k in range(3):
                r = soc_row(k, 0); rows.append(r); rows.append(-r)
            for s in range(S):
                for k in range(3, H):
                    r = soc_row(k, s); rows.append(r); rows.append(-r)
            for k in (1, 2):
                r = np.zeros(nv); r[k] = 1; r[3 + k] = -1; r[6 + k] = -1; rows.append(r)
            for j in range(Sn):
                r = np.zeros(nv); r[0] = 1; r[3] = -1; r[9 + S * 3 * M + j] = -1; rows.append(r)
            for s in range(S):
                o = 9 + s * 3 * M
                for k in range(M):
                    r = np.zeros(nv); r[o + k] = 1; r[o + M + k] = -1; r[o + 2 * M + k] = -1; rows.append(r)
            self._smat[key] = np.asarray(rows)
        return self._smat[key]

    def _plan_stoch(self, soc, cap, pmax, w, net, errs, sigw):
        """Hores 0-2 (mercat conegut): decisió comuna. Hores 3..H: S escenaris de preu/CO2 amb recurs."""
        H = len(w); S = self.cfg["S"]; Sn = len(errs); M = H - 3; z = np.asarray(self.ZS[S])
        A = self._smatrix(H, S, Sn); nv = A.shape[1]; eps = self.cfg["eps"]
        cost = np.full(nv, 0.0); cost[0:6] = eps; cost[7:9] = w[1:3]
        qo = self.cfg["q_out"] ** (np.arange(H) + 1) if self.outage else np.zeros(H)
        cost[3:6] += w[:3] * qo[:3]
        b = [np.tile([cap - soc, soc], 3)]
        for s in range(S):
            o = 9 + s * 3 * M; ws = np.maximum(w[3:] + z[s] * sigw, 0.0)
            cost[o:o + 2 * M] = eps / S; cost[o + M:o + 2 * M] += ws * qo[3:] / S; cost[o + 2 * M:o + 3 * M] = ws / S
            b.append(np.tile([cap - soc, soc], M))
        cost[9 + S * 3 * M:] = w[0] / Sn
        b += [-net[1:3], -(net[0] + errs)] + [-net[3:]] * S
        ub = [(0, pmax)] * 6 + [(0, None)] * 3
        for s in range(S): ub += [(0, pmax)] * (2 * M) + [(0, None)] * M
        ub += [(0, None)] * Sn
        res = linprog(cost, A_ub=A, b_ub=np.concatenate(b), bounds=ub, method="highs")
        if res.status != 0:
            return None
        return float(res.x[0] - res.x[3])

    # ------------------------------------------------------------- act
    def act(self, obs: dict) -> float:
        cap = float(obs.get("cap_max_kwh", 6000.0)); pmax = float(obs.get("power_max_kw", 1500.0))
        soc = float(obs["soc_kwh"])
        if not np.isfinite(soc):
            return 0.0
        soc = min(max(soc, 0.0), cap)
        try:
            pr, co = self._update(obs)
            n = len(pr)
            # final de la simulació: la llista de mercat s'escurça -> no planifiquem més enllà
            H = self.cfg["H"] if n >= 3 else n
            # el test acaba el 31/08/2026 a les 23h: no guardem energia per a després
            try:
                import pandas as pd
                left = int(round((pd.Timestamp(self.cfg["end_ts"]) - pd.Timestamp(obs["timestamp"])).total_seconds() / 3600.0))
                if 0 < left < H:
                    H = max(left, n)
            except Exception:
                pass
            price, co2, load, pv = self._forecasts(obs, H, pr, co)
            w = 0.7 * co2 + 0.3 * self.R * price
            net = load - pv
            v_term = self.cfg["term"] * float(np.median(w)) if n >= 3 else 0.0
            u0 = self._parts(obs["timestamp"], 0)[3]; clr0 = float(self.clear[u0[0][0], u0[1][0]])
            errs = self._scenarios(clr0); p = None
            if self.cfg["S"] > 1 and n >= 3 and H > 6:
                Hs = min(H, self.cfg["Hs"]); hL = int((int(obs["hour"]) + 2) % 24); k = Hs - 3
                sc, sp = 0.7 * self.co2.sig[hL, :k], 0.3 * self.R * self.price.sig[hL, :k]
                sigw = self.cfg["pscale"] * np.sqrt(sc ** 2 + sp ** 2 + 2 * self.rho * sc * sp)
                p = self._plan_stoch(soc, cap, pmax, w[:Hs], net[:Hs], errs, sigw)
            if p is None:
                p = self._plan(soc, cap, pmax, w, net, v_term, errs)
            if p is None:
                p = 0.0
            if p < 0 and self.cfg["kappa"] > 0:
                p = -min(-p, max(0.0, net[0] - self.cfg["kappa"]))
        except Exception:
            p = 0.0
        self.step += 1
        mc = max(0.0, min(pmax, (cap - soc) / ETA - 1e-4)); md = max(0.0, min(pmax, soc * ETA - 1e-4))
        p = float(min(max(p, -md), mc))
        return 0.0 if abs(p) < 1e-3 else p
